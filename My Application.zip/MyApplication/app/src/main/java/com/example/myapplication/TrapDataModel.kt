package com.example.seuapp

data class TrapDataModel(
    val id: Int,
    val location: String,
    val isOperational: Boolean,
    val maintenancePerformed: Boolean
)