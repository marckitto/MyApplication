package com.example.seuapp

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.seuapp.R


class FormularioActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_formulario)

        // Configuração da Toolbar
        val backButton: ImageView = findViewById(R.id.backButton)
        backButton.setOnClickListener {
            finish() // Voltar para a tela anterior
        }

        // Configuração do Spinner (Situação da Visita)
        val visitStatusSpinner: Spinner = findViewById(R.id.visitStatusSpinner)
        val visitStatusOptions = arrayOf("Trabalhado", "Não Trabalhado", "Em Progresso")
        visitStatusSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            visitStatusOptions
        )

        // Botão "Abrir Dados do Responsável"
        val openResponsibleDataButton: Button = findViewById(R.id.openResponsibleDataButton)
        openResponsibleDataButton.setOnClickListener {
            Toast.makeText(this, "Abrindo dados do responsável...", Toast.LENGTH_SHORT).show()
        }

        // Campo "Número da Armadilha" e botão "Escanear QRCode"
        val trapNumberEditText: EditText = findViewById(R.id.trapNumberEditText)
        val scanQRCodeButton: Button = findViewById(R.id.scanQRCodeButton)
        scanQRCodeButton.setOnClickListener {
            val trapNumber = trapNumberEditText.text.toString()
            if (trapNumber.isEmpty()) {
                Toast.makeText(this, "Por favor, insira o número da armadilha.", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Escaneando QRCode para armadilha $trapNumber...", Toast.LENGTH_SHORT).show()
            }
        }

        // Configuração do Spinner para Pergunta 2 (Manutenção da Armadilha)
        val maintenanceSpinner: Spinner = findViewById(R.id.maintenanceSpinner)
        val maintenanceOptions = arrayOf("Selecionar", "Sim", "Não")
        maintenanceSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            maintenanceOptions
        )

        // Configuração do Spinner para Pergunta 3 (Larva ou Pupa na Armadilha)
        val larvaSpinner: Spinner = findViewById(R.id.larvaSpinner)
        val larvaOptions = arrayOf("Selecionar", "Sim", "Não")
        larvaSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            larvaOptions
        )

        // Configuração do Spinner para Pergunta 5 (Gerada Amostra)
        val sampleSpinner: Spinner = findViewById(R.id.sampleSpinner)
        val sampleOptions = arrayOf("Selecionar", "Sim", "Não")
        sampleSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            sampleOptions
        )

        // Campos do formulário
        val blockEditText: EditText = findViewById(R.id.blockEditText)
        val cepEditText: EditText = findViewById(R.id.cepEditText)
        val streetEditText: EditText = findViewById(R.id.streetEditText)
        val houseNumberEditText: EditText = findViewById(R.id.houseNumberEditText)
        val propertyTypeSpinner: Spinner = findViewById(R.id.propertyTypeSpinner)
        val establishmentEditText: EditText = findViewById(R.id.establishmentEditText)
        val complementEditText: EditText = findViewById(R.id.complementEditText)
        val sequentialEditText: EditText = findViewById(R.id.sequentialEditText)

        // Configuração do Spinner "Tipo de Imóvel"
        val propertyTypeOptions = arrayOf("Residencial", "Comercial", "Industrial", "Outro")
        propertyTypeSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            propertyTypeOptions
        )

        // Botão "Avançar"
        val submitButton: Button = findViewById(R.id.submitButton)
        submitButton.setOnClickListener {
            // Validação dos campos
            val block = blockEditText.text.toString()
            val cep = cepEditText.text.toString()
            val street = streetEditText.text.toString()
            val houseNumber = houseNumberEditText.text.toString()
            val propertyType = propertyTypeSpinner.selectedItem.toString()
            val establishment = establishmentEditText.text.toString()
            val complement = complementEditText.text.toString()
            val sequential = sequentialEditText.text.toString()

            if (block.isEmpty() || cep.isEmpty() || street.isEmpty() || houseNumber.isEmpty() ||
                establishment.isEmpty() || complement.isEmpty() || sequential.isEmpty()
            ) {
                Toast.makeText(this, "Por favor, preencha todos os campos.", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Dados enviados com sucesso!", Toast.LENGTH_SHORT).show()
                // Aqui você pode enviar os dados para o servidor ou abrir outra tela
            }
        }
    }
}